#!/usr/bin/env python3
"""Local-only issue256 proof; main owns preflight/approval and future execution.

No shell, global-exclusive lease, isolated namespace, GUI, assets, or user:// IO.
Controlled work: two <=40s cases, <=90s overall, one <=8s cleanup reserve.
These are monotonic wait budgets, not hard-real-time guarantees.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import types

CASE_SECONDS = 40.0
OVERALL_SECONDS = 90.0
CLEANUP_SECONDS = 8.0
ENGINES = ("4.7.2-stable", "4.5.1-stable")
PROJECT = '''config_version=5
[application]
config/name="Issue256 private technical hold"
[debug]
file_logging/enable=false
[rendering]
renderer/rendering_method="gl_compatibility"
'''
HOLD = '''extends SceneTree
var expires_msec: int = Time.get_ticks_msec() + 20000
var stop_path: String = OS.get_environment("ISSUE256_STOP")
func _initialize() -> void:
	AudioServer.set_bus_mute(0, true)
	var ready: FileAccess = FileAccess.open(OS.get_environment("ISSUE256_READY"), FileAccess.WRITE)
	if ready == null:
		quit(91)
		return
	ready.store_string(JSON.stringify({"pid": OS.get_process_id(), "headless": DisplayServer.get_name() == "headless"}))
	ready.close()
func _process(_delta: float) -> bool:
	if FileAccess.file_exists(stop_path):
		quit(0)
	elif Time.get_ticks_msec() >= expires_msec:
		quit(92)
	return false
'''
SURVIVOR = '''import json, os, pathlib, sys, time
ready, stop = map(pathlib.Path, sys.argv[1:3])
end = float(sys.argv[3])
ready.write_text(json.dumps({"pid": os.getpid()}))
while time.monotonic() < end and not stop.exists():
    time.sleep(0.05)
sys.exit(0 if stop.exists() else 92)
'''


def digest(path):
    with Path(path).open("rb") as stream:
        value = hashlib.file_digest(stream, "sha256").hexdigest()
    return value


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def driver(config_path):
    """Import exactly the parent-approved bytes, never an installed verify copy."""
    config = json.loads(Path(config_path).read_text())
    source = Path(config["verifier"])
    raw = source.read_bytes()
    if hashlib.sha256(raw).hexdigest() != config["verifier_sha256"]:
        raise RuntimeError("frozen verifier changed before driver import")
    runtime = Path(os.environ["GODOT_COORDINATOR"]).resolve(strict=True)
    if str(runtime) != config["runtime"] or digest(runtime) != config["runtime_sha256"]:
        raise RuntimeError("canonical selector changed before actual verifier import")
    module = types.ModuleType("_issue256_frozen_verifier")
    module.__file__ = str(source)
    sys.modules[module.__name__] = module
    exec(compile(raw, str(source), "exec"), module.__dict__)
    report = {"runs": [], "loaded_verifier_sha256": config["verifier_sha256"]}
    code = 1
    try:
        module.run(config["command"], report, Path(config["run_dir"]),
                   config["label"], "shared", Path(config["project"]),
                   timeout=26, deadline=config["deadline"])
        code = 0
    except module.VerificationError as exc:
        code = exc.exit_code
        report["error"] = str(exc)
    finally:
        report["driver_exit"] = code
        save(config["driver_report"], report)
    return code


class Failure(RuntimeError):
    pass


class Blocked(Failure):
    pass


class Probe:
    def __init__(self, args):
        self.args = args
        self.started = time.monotonic()
        self.end = self.started + OVERALL_SECONDS
        self.selector = Path.home() / ".local/bin/godot-coordinator"
        self.runtime = self.selector.resolve(strict=True)
        self.verifier = Path(args.verifier).expanduser().resolve(strict=True)
        self.helper = Path(__file__).resolve(strict=True)
        self.env = {key: value for key, value in os.environ.items()
                    if not key.startswith("GODOT_COORDINATOR")
                    and key not in {"PYTHONPATH", "PYTHONHOME"}}
        self.env.update(GODOT_COORDINATOR=str(self.selector), PYTHONDONTWRITEBYTECODE="1")
        self.report = {"executed": True, "outcome": "FAIL", "mode": "headless",
                       "cleanup": {"complete": False},
                       "cases": [{"engine_version_label": version, "outcome": "NOT_RUN"}
                                 for version in ENGINES],
                       "scope": "actual frozen verifier.run TERM cancellation; two direct headless native leaves; neutral distinct-project survivor; not a launcher/native-guard, artwork, export, or full-gate proof",
                       "budgets_seconds": {"each_case": CASE_SECONDS, "overall": OVERALL_SECONDS,
                                           "final_cleanup_shared": CLEANUP_SECONDS},
                       "hard_realtime_claim": False,
                       "selector": str(self.selector), "resolved_runtime": str(self.runtime),
                       "runtime_sha256": digest(self.runtime), "verifier": str(self.verifier),
                       "verifier_sha256": digest(self.verifier), "helper_sha256": digest(self.helper),
                       "scrubbed_context_keys": sorted(key for key in os.environ
                                                        if key.startswith("GODOT_COORDINATOR"))}
        if self.report["verifier_sha256"] != args.verifier_sha256:
            raise Failure("parent-approved verifier hash mismatch")
        if self.report["runtime_sha256"] != args.runtime_sha256:
            raise Failure("parent-approved canonical runtime hash mismatch")
        self.artifacts = Path(args.out).expanduser().resolve().with_suffix("")
        self.artifacts = self.artifacts.with_name(self.artifacts.name + "-artifacts")
        self.artifacts.mkdir(parents=True, exist_ok=False)
        # delete=False preserves fixtures if cleanup cannot establish absence.
        self.temporary = tempfile.TemporaryDirectory(prefix="issue256-native-", delete=False)
        self.fixtures = Path(self.temporary.name).resolve()
        self.prefix = self.fixtures.name
        self.report.update(fixtures=str(self.fixtures), artifacts=str(self.artifacts))
        self.jobs = []
        self.stops = []
        self.latest = None

    def capture(self, command, end):
        """Only these owned, non-engine observation helpers may be hard-stopped."""
        remaining = min(2.0, end - time.monotonic())
        if remaining <= 0:
            raise Failure("observation deadline exhausted")
        process = subprocess.Popen(command, env=self.env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, text=True)
        try:
            stdout, stderr = process.communicate(timeout=remaining)
            return process.returncode, stdout, stderr
        except subprocess.TimeoutExpired as exc:
            raise Failure("bounded read-only observation timed out") from exc
        finally:
            if process.returncode is None:
                process.kill()  # this exact unreaped status/ps Popen only
                process.communicate(timeout=0.2)

    def status(self, label, end):
        code, stdout, stderr = self.capture(
            [sys.executable, str(self.runtime), "status", "--json"], end)
        if code:
            raise Failure(f"public status exit {code}: {stderr}")
        value = json.loads(stdout)
        if (value.get("domain") != "production" or not isinstance(value.get("active"), list)
                or not isinstance(value.get("waiting"), list)):
            raise Failure("refusing unknown/non-production public status schema")
        self.latest = value
        save(self.artifacts / f"{label}-status.json", value)
        return value

    def ps(self, pid, end):
        # Exact PID read only; no process-name scans and no PID-based signals.
        if type(pid) is not int or pid <= 0:
            raise Failure("invalid observation PID")
        code, stdout, stderr = self.capture(
            ["/bin/ps", "-ww", "-p", str(pid), "-o", "pid=,ppid=,lstart=,stat=,command="], end)
        if code not in (0, 1) or stderr.strip():
            raise Failure(f"ps observation failed: {code}: {stderr}")
        return stdout.strip()

    def launch(self, role, project, command, deadline, env=None):
        if time.monotonic() >= min(deadline, self.end):
            raise Failure("no new owned command after its case/overall deadline")
        purpose = f"{self.prefix} {role}"
        argv = [sys.executable, str(self.runtime), "run", "--mode", "shared",
                "--timeout", str(max(0.01, deadline - time.monotonic())),
                "--purpose", purpose]
        if project is not None:
            argv += ["--project", str(project)]
        argv += ["--", *command]
        log_path = self.artifacts / f"{role}-outer.log"
        with log_path.open("wb") as output:
            process = subprocess.Popen(argv, env=env or self.env, cwd=self.fixtures,
                                       stdout=output, stderr=subprocess.STDOUT)
        job = {"proc": process, "role": role, "purpose": purpose,
               "argv": argv, "log": str(log_path), "deadline": deadline}
        self.jobs.append(job)
        return job

    @staticmethod
    def matching(value, *, project=None, purpose=None):
        return [record for group in ("active", "waiting") for record in value[group]
                if ((project is not None and record.get("project") == str(project))
                    or (purpose is not None and purpose in record.get("purpose", "")))]

    def wait(self, predicate, end):
        while time.monotonic() < end:
            result = predicate()
            if result:
                return result
            time.sleep(min(0.1, max(0, end - time.monotonic())))
        return None

    @staticmethod
    def ready(path):
        try:
            value = json.loads(path.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            return None
        if not isinstance(value, dict) or type(value.get("pid")) is not int:
            raise Failure("invalid private readiness artifact")
        return value

    @staticmethod
    def pending(job):
        code = job["proc"].poll()
        if code is not None:
            raise Failure(f"{job['role']} wrapper exited {code} before readiness; inspect {job['log']}")
        return None

    def witness(self, root, ready, outer, label, end):
        value = self.status(label, end)
        matches = [record for record in value["active"]
                   if record.get("project") == str(root) and record.get("kind") == "command"
                   and record.get("mode") == "shared"
                   and isinstance(record.get("child"), dict)
                   and record["child"].get("pid") == ready["pid"]
                   and isinstance(record["child"].get("start"), str)
                   and record["child"]["start"]]
        if len(matches) != 1:
            raise Failure("no unique live canonical project command/child PID+start witness")
        if outer["proc"].poll() is not None:
            raise Failure("outer CLI exited before live native/survivor witness")
        process_row = self.ps(ready["pid"], end)
        if not process_row:
            raise Failure("witnessed child disappeared before exact-PID ps observation")
        return value, matches[0], process_row

    def case(self, version):
        end = min(self.end, time.monotonic() + CASE_SECONDS)
        tag = version.removesuffix("-stable")
        result = next(case for case in self.report["cases"] if case["engine_version_label"] == version)
        result["outcome"] = "FAIL"
        result["case_deadline_monotonic"] = end
        engine = (Path.home() / ".local/share/godot" / version
                  / "Godot.app/Contents/MacOS/Godot").resolve(strict=True)
        expected = self.args.engine_4_7_2_sha256 if version == ENGINES[0] else self.args.engine_4_5_1_sha256
        result.update(engine=str(engine), engine_sha256=digest(engine))
        if result["engine_sha256"] != expected:
            raise Failure(f"{version} parent-approved engine hash mismatch")
        root = self.fixtures / f"native-{tag}"
        survivor_root = self.fixtures / f"survivor-{tag}"
        root.mkdir()
        survivor_root.mkdir()
        (root / "project.godot").write_text(PROJECT)
        (root / "hold.gd").write_text(HOLD)
        (survivor_root / "project.godot").write_text(PROJECT)
        (survivor_root / "survivor.py").write_text(SURVIVOR)
        sources = [root / "project.godot", root / "hold.gd",
                   survivor_root / "project.godot", survivor_root / "survivor.py"]
        before = {str(path): digest(path) for path in sources}
        result.update(canonical_project=str(root), survivor_project=str(survivor_root),
                      sources_before=before)
        stop, survivor_stop = root / "stop", survivor_root / "stop"
        self.stops += [stop, survivor_stop]
        ready, survivor_ready = root / "ready.json", survivor_root / "ready.json"
        survivor = self.launch(f"{tag}-survivor", survivor_root,
                              [sys.executable, str(survivor_root / "survivor.py"),
                               str(survivor_ready), str(survivor_stop), str(end - 2)], end - 1)
        event = self.wait(lambda: self.ready(survivor_ready) or self.pending(survivor),
                          min(end - 4, time.monotonic() + 6))
        if not event:
            self.status(f"{tag}-survivor-not-ready", end)
            raise Blocked("neutral distinct-project survivor did not become ready; no retry")
        result["survivor_ready"] = event
        _, survivor_record, survivor_ps = self.witness(survivor_root, event, survivor,
                                                       f"{tag}-survivor-ready", end)
        result.update(survivor_witness=survivor_record, survivor_ps_before=survivor_ps)
        label = f"{self.prefix}-{tag}-native"
        run_dir = self.artifacts / f"{tag}-run"
        run_dir.mkdir()
        deadline = min(end - 3, time.monotonic() + 28)
        command = [str(engine), "--headless", "--audio-driver", "Dummy", "--path", str(root),
                   "--log-file", str(run_dir / f"{label}-engine.log"), "--script", "res://hold.gd"]
        config = {"verifier": str(self.verifier), "verifier_sha256": self.args.verifier_sha256,
                  "runtime": str(self.runtime), "runtime_sha256": self.args.runtime_sha256,
                  "command": command, "project": str(root), "label": label,
                  "run_dir": str(run_dir), "deadline": deadline,
                  "driver_report": str(run_dir / "driver-report.json")}
        config_path = run_dir / "driver-config.json"
        save(config_path, config)
        env = dict(self.env, ISSUE256_READY=str(ready), ISSUE256_STOP=str(stop))
        outer = self.launch(f"{tag}-target", None,
                            [sys.executable, str(self.helper), "_driver", str(config_path)], deadline, env)
        result["outer_pid"] = outer["proc"].pid
        readiness_end = min(deadline - 5, time.monotonic() + 12)
        result.update(outer_deadline_monotonic=deadline, readiness_deadline_monotonic=readiness_end)
        event = self.wait(lambda: self.ready(ready) or self.pending(outer), readiness_end)
        if not event:
            self.status(f"{tag}-native-not-ready", end)
            raise Blocked("actual native leaf did not become ready before finite readiness D; no retry")
        result["native_ready"] = event
        if event.get("headless") is not True:
            raise Failure("actual child did not report the headless display backend")
        value, leaf, native_ps = self.witness(root, event, outer, f"{tag}-native-ready", end)
        if str(engine) not in native_ps or "--headless" not in native_ps or str(root) not in native_ps:
            raise Failure("actual exact-PID ps does not show pinned headless engine/project argv")
        outers = [record for record in value["active"]
                  if record.get("purpose") == outer["purpose"]
                  and record.get("owner", {}).get("pid") == outer["proc"].pid
                  and record.get("project") is None and record.get("kind") == "command"]
        by_id = {record["id"]: record for record in value["active"]}
        ancestors, cursor = set(), leaf
        while cursor.get("parent") and cursor["parent"] not in ancestors:
            ancestors.add(cursor["parent"])
            cursor = by_id.get(cursor["parent"], {})
        if len(outers) != 1 or outers[0]["id"] not in ancestors:
            raise Failure("native project leaf lacks the actual rootless outer CLI admission ancestry")
        result.update(native_ready=event, native_witness=leaf, native_ps_before=native_ps,
                      rootless_outer_witness=outers[0], signal="SIGTERM",
                      signal_authority="actual unreaped direct outer CLI Popen only")
        if outer["proc"].poll() is not None:
            raise Failure("outer CLI exited before cancellation")
        outer["proc"].send_signal(signal.SIGTERM)
        code = self.wait(lambda: (outer["proc"].poll(),) if outer["proc"].poll() is not None else None,
                         min(deadline, time.monotonic() + 8))
        result["outer_exit"] = code[0] if code else None
        if not code or code[0] != 143:
            raise Failure(f"actual outer CLI exit was {result['outer_exit']!r}, required 143")
        value = self.status(f"{tag}-after-cancel", end)
        remaining = (self.matching(value, project=root, purpose=label)
                     + self.matching(value, purpose=outer["purpose"]))
        native_after = self.ps(event["pid"], end)
        result.update(native_ps_after=native_after, target_claims_after_cancel=remaining)
        if native_after or remaining:
            raise Failure("cancelled native PID or target admission claims remain")
        _, survivor_after, survivor_ps_after = self.witness(
            survivor_root, {"pid": survivor_record["child"]["pid"]}, survivor,
            f"{tag}-survivor-after-cancel", end)
        after = {str(path): digest(path) for path in sources}
        result.update(survivor_after_cancel=survivor_after, survivor_ps_after=survivor_ps_after,
                      sources_after=after)
        if survivor_after["child"] != survivor_record["child"] or before != after:
            raise Failure("unrelated survivor identity or private source bytes changed")
        survivor_stop.touch(exist_ok=False)
        released = self.wait(lambda: (survivor["proc"].poll(),) if survivor["proc"].poll() is not None else None,
                             end - 1)
        result["survivor_exit"] = released[0] if released else None
        value = self.status(f"{tag}-released", end)
        if (not released or released[0] != 0 or self.matching(value, project=survivor_root)
                or self.matching(value, purpose=self.prefix)
                or self.ps(survivor_record["child"]["pid"], end)):
            raise Failure("cooperative neutral survivor release/claim cleanup not established")
        result["driver_report"] = json.loads(Path(config["driver_report"]).read_text())
        if (result["driver_report"].get("driver_exit") != 143
                or result["driver_report"].get("loaded_verifier_sha256") != self.args.verifier_sha256):
            raise Failure("actual verifier driver exit/hash evidence missing or mismatched")
        result["outcome"] = "PASS"

    def cleanup(self):
        end = time.monotonic() + CLEANUP_SECONDS
        result = {"complete": False, "signals": [], "errors": []}
        self.report["cleanup"] = result
        for stop in self.stops:
            try:
                stop.touch(exist_ok=True)
            except OSError as exc:
                result["errors"].append(str(exc))
        # Cooperative stop first. Never signal an artifact/status PID or a group.
        self.wait(lambda: all(job["proc"].poll() is not None for job in self.jobs),
                  min(end, time.monotonic() + 1))
        for job in self.jobs:
            if job["proc"].poll() is None:
                try:
                    job["proc"].terminate()
                    result["signals"].append({"role": job["role"], "popen_pid": job["proc"].pid,
                                              "signal": "SIGTERM"})
                except ProcessLookupError:
                    pass
                except OSError as exc:
                    result["errors"].append(f"{job['role']}: {exc}")
        # Shared reserve, not eight seconds per job; never SIGKILL a supervisor.
        self.wait(lambda: all(job["proc"].poll() is not None for job in self.jobs), end - 2.2)
        result["jobs"] = [{"role": job["role"], "popen_pid": job["proc"].pid,
                           "exit": job["proc"].poll(), "argv": job["argv"], "log": job["log"]}
                          for job in self.jobs]
        for case in self.report["cases"]:
            tag = case["engine_version_label"].removesuffix("-stable")
            for job in self.jobs:
                if job["role"] == f"{tag}-target":
                    case["outer_exit_after_cleanup"] = job["proc"].returncode
                elif job["role"] == f"{tag}-survivor":
                    case["survivor_exit_after_cleanup"] = job["proc"].returncode
        try:
            value = self.status("final-cleanup", end)
            claims = self.matching(value, purpose=self.prefix)
            result["remaining_claims"] = claims
            observed_pids = {case["native_ready"]["pid"] for case in self.report["cases"]
                             if "native_ready" in case}
            observed_pids.update(case["survivor_ready"]["pid"]
                                 for case in self.report["cases"] if "survivor_ready" in case)
            rows = {str(pid): self.ps(pid, end) for pid in observed_pids}
            result["exact_pid_rows"] = rows
            result["complete"] = (not claims and not any(rows.values())
                                  and all(job["proc"].returncode is not None for job in self.jobs)
                                  and not result["errors"])
        except Exception as exc:
            result["errors"].append(str(exc))
        if result["complete"]:
            self.temporary.cleanup()
            result["private_fixtures_removed"] = True
        else:
            result["private_fixtures_removed"] = False
            result["retained_fixtures"] = str(self.fixtures)
        result["elapsed_seconds"] = CLEANUP_SECONDS - max(0, end - time.monotonic())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verifier", required=True)
    parser.add_argument("--verifier-sha256", required=True)
    parser.add_argument("--runtime-sha256", required=True)
    parser.add_argument("--engine-4-7-2-sha256", required=True)
    parser.add_argument("--engine-4-5-1-sha256", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        parser.error("Python >=3.12 is required for explicit retained TemporaryDirectory cleanup")
    out = Path(args.out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    interrupted = False
    def abort(signum, _frame):
        nonlocal interrupted
        if not interrupted:
            interrupted = True
            raise Failure(f"proof helper interrupted by signal {signum}")
    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, abort)
    with out.open("x") as output:
        probe = None
        report = {"executed": False, "outcome": "FAIL", "cleanup": {"complete": False}}
        try:
            # Keep the object available for cleanup even when initialization fails.
            probe = Probe.__new__(Probe)
            probe.__init__(args)
            report = probe.report
            probe.status("before", probe.end)
            for version in ENGINES:
                probe.case(version)
            report["outcome"] = "PASS"
        except Blocked as exc:
            report = probe.report
            report["outcome"], report["error"] = "BLOCKED", str(exc)
            for case in report["cases"]:
                if case["outcome"] == "FAIL":
                    case["outcome"] = "BLOCKED"
        except Exception as exc:
            if probe is not None and hasattr(probe, "report"):
                report = probe.report
            report["outcome"], report["error"] = "FAIL", f"{type(exc).__name__}: {exc}"
        finally:
            if probe is not None and hasattr(probe, "jobs"):
                try:
                    probe.cleanup()
                except Exception as exc:
                    probe.report["cleanup"] = {"complete": False, "error": str(exc),
                                               "retained_fixtures": str(probe.fixtures)}
                report = probe.report
                try:
                    report["verifier_sha256_after"] = digest(probe.verifier)
                    report["runtime_sha256_after"] = digest(probe.runtime)
                    report["selector_target_after"] = str(probe.selector.resolve(strict=True))
                    report["helper_sha256_after"] = digest(probe.helper)
                    report["engine_sha256_after"] = {
                        case["engine_version_label"]: digest(case["engine"])
                        for case in report["cases"] if "engine" in case}
                    unchanged = (report["verifier_sha256_after"] == args.verifier_sha256
                                 and report["runtime_sha256_after"] == args.runtime_sha256
                                 and report["selector_target_after"] == str(probe.runtime)
                                 and report["helper_sha256_after"] == report["helper_sha256"]
                                 and all(report["engine_sha256_after"][case["engine_version_label"]]
                                         == case["engine_sha256"]
                                         for case in report["cases"] if "engine" in case))
                    report["frozen_sources_unchanged"] = unchanged
                except Exception as exc:
                    unchanged = False
                    report["source_recheck_error"] = str(exc)
                if report.get("outcome") == "PASS" and (not unchanged or not report["cleanup"]["complete"]):
                    report["outcome"] = "FAIL"
                report["elapsed_seconds"] = time.monotonic() - probe.started
            output.write(json.dumps(report, indent=2, allow_nan=False) + "\n")
            output.flush()
    print(json.dumps({"outcome": report["outcome"], "report": str(out),
                      "cleanup_complete": report["cleanup"]["complete"]}))
    return {"PASS": 0, "BLOCKED": 3}.get(report["outcome"], 1)


if __name__ == "__main__":
    raise SystemExit(driver(sys.argv[2]) if len(sys.argv) > 1 and sys.argv[1] == "_driver" else main())
